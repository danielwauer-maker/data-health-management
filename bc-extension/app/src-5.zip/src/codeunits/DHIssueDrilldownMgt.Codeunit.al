codeunit 53142 "DH Issue Drilldown Mgt."
{
    procedure OpenDashboardIssue(var DashboardIssue: Record "DH Dashboard Issue")
    begin
        EnsurePremiumActionAccess();
        OpenByIssueCode(DashboardIssue."Issue Code");
    end;

    procedure OpenScanIssue(var ScanIssue: Record "DH Scan Issue")
    begin
        EnsurePremiumActionAccess();
        OpenByIssueCode(ScanIssue."Issue Code");
    end;

    procedure OpenDeepScanFinding(var DeepFinding: Record "DH Deep Scan Finding")
    begin
        EnsurePremiumActionAccess();
        OpenByIssueCode(DeepFinding."Issue Code");
    end;

    local procedure EnsurePremiumActionAccess()
    var
        Setup: Record "DH Setup";
    begin
        if not Setup.Get('SETUP') then
            Error('Setup not found.');

        if not Setup.IsPremiumLicenseActive() then
            Error('Premium is required to open record details and correction worklists. Free shows the full scan result, but actions and recommendations are unlocked only with an active Premium license.');
    end;

    local procedure OpenByIssueCode(IssueCode: Code[50])
    var
        IssueDrilldownDispatcher: Codeunit "DH Issue Drilldown Dispatcher";
    begin
        IssueDrilldownDispatcher.OpenByIssueCode(IssueCode);
    end;
}
