from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # === CORE ===
    ENV: str = "dev"

    # === SECURITY ===
    SECRET_KEY: str
    ADMIN_USERNAME: str
    ADMIN_PASSWORD: str

    # === DATABASE ===
    DATABASE_URL: str

    # === TOKEN ===
    TOKEN_EXPIRE_MINUTES: int = 60

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()


def validate_settings():
    missing = []

    if not settings.SECRET_KEY:
        missing.append("SECRET_KEY")

    if not settings.ADMIN_USERNAME:
        missing.append("ADMIN_USERNAME")

    if not settings.ADMIN_PASSWORD:
        missing.append("ADMIN_PASSWORD")

    if not settings.DATABASE_URL:
        missing.append("DATABASE_URL")

    if missing:
        raise RuntimeError(f"Missing required environment variables: {missing}")

    if settings.ENV == "prod" and settings.SECRET_KEY == "changeme":
        raise RuntimeError("SECRET_KEY is insecure in production")
